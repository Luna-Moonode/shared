var registerArea = document.getElementById("register");
function register() {
    registerArea.className = "activeRegister"
}